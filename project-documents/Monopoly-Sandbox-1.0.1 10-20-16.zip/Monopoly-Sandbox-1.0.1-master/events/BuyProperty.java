//Flat out buying any property & Mortaging it for half of the cost of buying the property

/*
Buy (Mortgage is buy/2 with no rent on item until other half is paid to the bank)
Purple: Germania Inferior $60, Germania Superior $60
Baby Blue: Alpes Poeniae $100, Alpes Cottiae $100, Aples Maritimae $120
Dark Pink: Aquitania $140, Belgica $140, Raetia $160
Orange: Africa Proconsularis $180, Asia $180, Britannia $200
Red: Cilicia $220, Galatia $220, Cappadocia $240
Yellow: Aegyptus $260, Arabia Petraea $260, Syria $280
Green: Macedonia $300, Epirus $300, Achaia $320
Blue: Sicilia $350, Italia $400
Via: $200
Water: $150
*/
