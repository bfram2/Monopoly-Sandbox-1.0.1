//Go to Jail: Go to the Gladitorial Arena

/*
Check for Get out of the Arena free card, then move to the arena
wait for player to roll doubles to get out or to receive a get out of the arena free card

2nd set of coding (later): If doubles, roll again, if doubles a second time go to jail
*/
