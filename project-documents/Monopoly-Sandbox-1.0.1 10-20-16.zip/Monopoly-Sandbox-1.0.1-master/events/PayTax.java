//Pay the Income Tax and Luxuary Tax

/*
1 Luxury tax space = Citizen’s Tax Pay $100
1 Income tax space = Render unto Caesar $200
*/
