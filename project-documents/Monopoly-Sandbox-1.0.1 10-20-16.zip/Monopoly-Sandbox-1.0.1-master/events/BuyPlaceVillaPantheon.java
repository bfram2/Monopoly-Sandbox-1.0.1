//Buying and choosing where to play a Villa or Pantheon (if player has 4 Villas)


/*
Germania Inferior: Houses cost $50 each, Hotels: $50 each plus 4 houses
Germania Superior: Houses cost $50 each, Hotels: $50 each plus 4 houses
Alpes Poeniae: Houses cost $50 each, Hotels: $50 each plus 4 houses
Alpes Cottiae: Houses cost $50 each, Hotels: $50 each plus 4 houses
Aples Maritimae: Houses cost $50 each, Hotels: $50 each plus 4 houses
Aquitania: Houses cost $100 each, Hotels: $100 each plus 4 houses
Belgica: Houses cost $100 each, Hotels: $100 each plus 4 houses
Raetia: Houses cost $100 each, Hotels: $100 each plus 4 houses
Africa Proconsularis: Houses cost $100 each, Hotels: $100 each plus 4 houses
Asia: Houses cost $100 each, Hotels: $100 each plus 4 houses
Britannia: Houses cost $100 each, Hotels: $100 each plus 4 houses
Cilicia: Houses cost $150 each, Hotels: $150 each plus 4 houses
Galatia: Houses cost $150 each, Hotels: $150 each plus 4 houses
Cappadocia: Houses cost $150 each, Hotels: $150 each plus 4 houses
Aegyptus: Houses cost $150 each, Hotels: $150 each plus 4 houses 
Arabia Petraea: Houses cost $150 each, Hotels: $150 each plus 4 houses
Syria: Houses cost $150 each, Hotels: $150 each plus 4 houses
Macedonia: Houses cost $200 each, Hotels: $200 each plus 4 houses
Epirus: Houses cost $200 each, Hotels: $200 each plus 4 houses
Achaia: Houses cost $200 each, Hotels: $200 each plus 4 houses
Sicilia: Houses cost $200 each, Hotels: $200 each plus 4 houses 
Italia: Houses cost $200 each, Hotels: $200 each plus 4 houses
*/
