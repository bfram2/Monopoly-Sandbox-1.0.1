//land on a Chance or Community Chest space

/* pull a random card from the files in the card folder using an array */
