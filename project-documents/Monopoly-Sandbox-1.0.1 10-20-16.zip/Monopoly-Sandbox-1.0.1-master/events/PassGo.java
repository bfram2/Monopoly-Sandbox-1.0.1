//Player has Gone to Rome, go to 'Go' space and Collect $200
//Activated by cards and token movement
//Go to the Arena should deactivate this for token movement

/*
Chance Cards:
Take a trip to Via Appia. If you pass Rome collect $200.
Advance to Rome. Collect $200.
Advance to Aquitania. If you pass Rome, Collect $200.
Advance to Cappadocia. If you pass Rome, Collect $200.

Community Chest:
Advance to Rome. Collect $200.
*/
