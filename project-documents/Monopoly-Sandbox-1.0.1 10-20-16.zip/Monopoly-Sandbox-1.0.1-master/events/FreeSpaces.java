// Seeing a show at the Arena and Free Market Trade
/*
no rent, tax, or buying
move token only
*/
