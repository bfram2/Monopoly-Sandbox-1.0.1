// 8 Tokens and their movement across the board
// Tokens: Token_E.png, Token_H.png, Token_S1.png, Token_S2.png, Token_S3.png, Token_Sen.png, Token_W1.png, Token_W2.png  
