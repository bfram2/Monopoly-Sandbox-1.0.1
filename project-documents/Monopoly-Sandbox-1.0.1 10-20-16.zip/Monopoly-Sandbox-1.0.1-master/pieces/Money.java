//Money using Roman conversion
//Use images of the dollar bills or money counter with just the digits ie. 100.00 denarius
//each player starts with 1500.00 denarius
//the bank never runs out of money

/*
20 $500 Bills (orange) = aureus
20 $100 Bills (beige) = denarius
30 $50 Bills (blue) = sestertius
50 $20 Bills (green) = dupondius
40 $10 Bills (yellow) = as
40 $5 Bills (pink) = semis
40 $1 Bills (white) = triens

*/
