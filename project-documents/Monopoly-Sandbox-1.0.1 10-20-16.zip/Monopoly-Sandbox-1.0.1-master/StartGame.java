//The Main Menu for the game to start and to pick the players, type of game, citation, and help.
/* Trademark of Hasboro and Parker Brothers */

//guide to implement folders into master
//import pieces.*;
//import menu.*;
//import events.*;
//import cards.*;
//start the game
import menu.MainMenu;

public class StartGame {
	//main
	public static void main(String args[]) {
	new MainMenu(); //open menu page
	
	}
}
