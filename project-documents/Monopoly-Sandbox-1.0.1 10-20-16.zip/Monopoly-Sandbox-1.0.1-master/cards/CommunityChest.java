//For Community Chest Cards, activate using images or background image with text.

/*
src/cards/images/Chest1-16.PNG
1. Bank error in your favor. Collect $200.
2. Pay private physician fees of $100.
3. From sale of merchant carts, you get $50.
4. You inherit a small Villa, gain $100.
5. Go to the Gladiatorial Arena. Go directly to the arena, DO NOT pass Rome, DO NOT collect $200.
6. Advance to Rome. Collect $200.
7. Render too much unto Caesar, Collect $200.
8. Roman official assesses you for street repairs: $40 per villa, $115 per pantheon.
9. You have won the second price in the Campus Track & Field foot race. Collect $10.
10. Your properties and assets mature, join the Equestrian Order. Collect $100.
11. Sell bulk staples to the bank, receive $100.
12. Pay farmer’s tax of $25.
13. You have a coming of age party, Collect $10 from every player.
14. Pay school fees of $50.
15. Medical institution fees, pay $50.
16. Gain a favor with a Senator, get out of the Gladiatorial Arena for free. This card may be kept until needed or traded.
*/
