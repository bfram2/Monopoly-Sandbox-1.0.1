//For Chance Cards, using image or background image with text.

/*
src/cards/images/Chance1-16.PNG
1.Take a trip to Via Appia. If you pass Rome collect $200.
2,3. Advance to the nearest Via. If UNOWNED, you may buy it from the Bank. 
If OWNED, pay owner twice the rental to which they are otherwise entitled.

4. Gain a favor with a Senator, get out of the Gladiatorial Arena for free. This card may be kept until needed or traded.
5. Advance to the nearest Utility. If UNOWNED, you may buy it from the Bank. 
If OWNED, throw dice and pay owner a total ten times amount thrown.

6. Advance to Rome. Collect $200.
7. A new road is built near your Villa raising its value, collect $150.
8. Go back 3 spaces.
9. Make general repairs on all of your properties: For villa pay $25, For pantheons pay $100.
10. Advance to Italia.
11. Recent investment in more merchant carts gains you $50.
12. Your horses escape into the city. Pay a $15 fine.
13. Go to the Gladiatorial Arena. Go directly to the arena, DO NOT pass Rome, DO NOT collect $200.
14. Advance to Aquitania. If you pass Rome, Collect $200.
15. Advance to Cappadocia. If you pass Rome, Collect $200.
16. You have been elected a Senator, pay each player $50.
*/
