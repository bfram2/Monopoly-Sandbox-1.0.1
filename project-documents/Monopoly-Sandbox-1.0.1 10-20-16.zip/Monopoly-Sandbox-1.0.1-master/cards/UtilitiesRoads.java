//For implementing the Utilities and Road cards, use image or background image over text.

/*
1 utility: 4 times dice total. both utilities: are 10 times dice total
   Aqueducts
   Sewers

Rent: 25
2 owned: 25*2
3 owned: 50*2
4 owned: 100*2
   Via Appia
   Via Flaminia
   Via Aemilia
   Via Popillia

*/
